export type Page = 'welcome' | 'home' | 'search' | 'live' | 'movies' | 'series' | 'details' | 'player' | 'profile';

export interface ContentItem {
  id: string;
  title: string;
  type: 'movie' | 'series';
  year: number;
  genre: string[];
  rating: number;
  duration: string;
  seasons?: number;
  totalEpisodes?: number;
  description: string;
  poster: string;
  backdrop: string;
  ageRating: string;
  cast: string[];
  director: string;
  progress?: number;
}

export interface LiveChannel {
  id: string;
  name: string;
  category: string;
  currentProgram: string;
  nextProgram: string;
  currentTime: string;
  thumbnail: string;
  viewers: string;
  color: string;
}

export type NavigateFn = (page: Page, item?: ContentItem) => void;

const p = (seed: string) => `https://picsum.photos/seed/${seed}/300/450`;
const b = (seed: string) => `https://picsum.photos/seed/${seed}/1280/720`;

export const movies: ContentItem[] = [
  {
    id: 'm1', title: 'Phantom Eclipse', type: 'movie', year: 2024,
    genre: ['Sci-Fi', 'Action'], rating: 8.4, duration: '2h 18m',
    description: 'When a rogue AI awakens inside a decommissioned orbital station, a covert team of engineers must race against time to prevent a cascade failure that could wipe out all communications on Earth.',
    poster: p('phantom1'), backdrop: b('phantom1bg'),
    ageRating: 'PG-13', cast: ['Zara Voss', 'Eli Nakamura', 'Sasha Reyes', 'Dom Carver'], director: 'Mira Holst',
  },
  {
    id: 'm2', title: 'Crimson Horizon', type: 'movie', year: 2023,
    genre: ['Thriller', 'Drama'], rating: 7.9, duration: '1h 54m',
    description: 'A war photographer returns from a forgotten conflict only to find that the atrocities she documented have followed her home — hiding in plain sight.',
    poster: p('crimson2'), backdrop: b('crimson2bg'),
    ageRating: 'R', cast: ['Nadia Kell', 'Marcus Strand', 'Yuki Tanaka'], director: 'Olu Mensah',
  },
  {
    id: 'm3', title: 'Neon Requiem', type: 'movie', year: 2024,
    genre: ['Cyberpunk', 'Neo-Noir'], rating: 8.7, duration: '2h 31m',
    description: 'In a rain-soaked megacity where memory can be bought and sold, a disgraced detective hunts for the only thing money cannot purchase: the truth.',
    poster: p('neon3'), backdrop: b('neon3bg'),
    ageRating: 'R', cast: ['Cas Delvaux', 'Ines Mura', 'Teo Falco', 'Britt Wren'], director: 'Jin Soo Park',
    progress: 62,
  },
  {
    id: 'm4', title: 'Silent Depths', type: 'movie', year: 2023,
    genre: ['Horror', 'Mystery'], rating: 7.3, duration: '1h 48m',
    description: 'A deep-sea research crew discovers something ancient and alive beneath the Mariana Trench — and it has already learned how to find them.',
    poster: p('silent4'), backdrop: b('silent4bg'),
    ageRating: 'R', cast: ['Petra Volk', 'Sam Obi', 'Cleo Marsh'], director: 'Astrid Heil',
  },
  {
    id: 'm5', title: 'Iron Veil', type: 'movie', year: 2024,
    genre: ['Action', 'Superhero'], rating: 7.6, duration: '2h 22m',
    description: 'The last line of defense between humanity and extinction is a disavowed soldier with an exosuit powered by a dying star fragment.',
    poster: p('iron5'), backdrop: b('iron5bg'),
    ageRating: 'PG-13', cast: ['Rex Dorn', 'Ayla Singh', 'Victor Cruz', 'Nora Fenn'], director: 'T.J. Rowe',
    progress: 35,
  },
  {
    id: 'm6', title: 'Eternal Drift', type: 'movie', year: 2023,
    genre: ['Romance', 'Drama'], rating: 8.1, duration: '2h 03m',
    description: 'Two strangers meet on a sleeper train crossing Eurasia. Over four thousand miles, they share secrets neither has ever spoken aloud.',
    poster: p('eternal6'), backdrop: b('eternal6bg'),
    ageRating: 'PG-13', cast: ['Lea Fontaine', 'Arash Nazari'], director: 'Sofia Brandt',
  },
  {
    id: 'm7', title: 'The Obsidian Code', type: 'movie', year: 2024,
    genre: ['Spy', 'Thriller'], rating: 8.0, duration: '2h 09m',
    description: 'A retired cryptographer is pulled back into the shadows when she realizes the cipher she designed decades ago is being used to coordinate the largest cyberattack in history.',
    poster: p('obsidian7'), backdrop: b('obsidian7bg'),
    ageRating: 'PG-13', cast: ['Helen Marsh', 'Omar Diaz', 'Kat Lorne'], director: 'Blake Renner',
  },
  {
    id: 'm8', title: 'Astral Fracture', type: 'movie', year: 2023,
    genre: ['Sci-Fi', 'Adventure'], rating: 8.3, duration: '2h 27m',
    description: 'A probe returns from beyond the solar system carrying coordinates to a place that does not appear on any star chart — and a warning not to go there.',
    poster: p('astral8'), backdrop: b('astral8bg'),
    ageRating: 'PG', cast: ['Daan Wilder', 'Priya Sato', 'Cal Brennan', 'Freya Cole'], director: 'Hans Vogel',
    progress: 88,
  },
  {
    id: 'm9', title: 'Blood & Silence', type: 'movie', year: 2024,
    genre: ['Crime', 'Thriller'], rating: 7.7, duration: '1h 57m',
    description: 'When a string of seemingly unrelated crimes leads a homicide detective to a single fingerprint — her own — she must question everything she thinks she knows about herself.',
    poster: p('blood9'), backdrop: b('blood9bg'),
    ageRating: 'R', cast: ['Mona Drax', 'Leo Vance', 'Aiko Shen'], director: 'Caro Weiss',
  },
  {
    id: 'm10', title: 'Starfall Protocol', type: 'movie', year: 2024,
    genre: ['Sci-Fi', 'Action'], rating: 8.5, duration: '2h 15m',
    description: "After an unexplained pulse disables every satellite orbiting Earth, the world's militaries go dark — and one signals analyst must figure out why before the silence becomes permanent.",
    poster: p('starfall10'), backdrop: b('starfall10bg'),
    ageRating: 'PG-13', cast: ['Jade Reeves', 'Finn Okoro', 'Sora Ito', 'Ben Holt'], director: 'Yuna Kim',
  },
  {
    id: 'm11', title: 'The Glass Theorem', type: 'movie', year: 2024,
    genre: ['Mystery', 'Psychological'], rating: 9.0, duration: '2h 42m',
    description: 'A reclusive mathematician claims to have proved that free will is an illusion — moments before she disappears without a trace, leaving only an equation that no one can solve.',
    poster: p('glass11'), backdrop: b('glass11bg'),
    ageRating: 'R', cast: ['Vera Kohl', 'Seth Adair', 'Carmen Lux'], director: 'Noa Friedman',
  },
  {
    id: 'm12', title: 'Dark Continuum', type: 'movie', year: 2023,
    genre: ['Sci-Fi', 'Horror'], rating: 7.5, duration: '1h 52m',
    description: 'An expedition into an uncharted region of Antarctica uncovers something buried beneath the ice that should not exist: a city older than civilization.',
    poster: p('dark12'), backdrop: b('dark12bg'),
    ageRating: 'R', cast: ['Greta Sorel', 'Nick Bane', 'Tara Voss'], director: 'Lars Holst',
  },
  {
    id: 'm13', title: 'Midnight Syndicate', type: 'movie', year: 2023,
    genre: ['Crime', 'Noir'], rating: 8.2, duration: '2h 06m',
    description: 'Three rival crime families negotiate an uneasy truce over a stolen artifact — not knowing that the artifact is watching all of them.',
    poster: p('midnight13'), backdrop: b('midnight13bg'),
    ageRating: 'R', cast: ['Rocco Lane', 'Bianca Solis', 'Henry Fang', 'Delia Storm'], director: 'Marco Belli',
  },
  {
    id: 'm14', title: 'Venom Circuit', type: 'movie', year: 2024,
    genre: ['Cyberpunk', 'Action'], rating: 7.8, duration: '2h 01m',
    description: 'A street-level hacker discovers that every major corporation on the planet is connected by a single hidden network — and someone has just sent her the password.',
    poster: p('venom14'), backdrop: b('venom14bg'),
    ageRating: 'R', cast: ['Nia Cross', 'Dante Kael', 'Suki Rao'], director: 'Ren Ishida',
  },
  {
    id: 'm15', title: 'Echo Chamber', type: 'movie', year: 2024,
    genre: ['Thriller', 'Mystery'], rating: 8.6, duration: '2h 20m',
    description: 'A forensic audio analyst realizes that hidden inside a famous symphony recorded sixty years ago is a voice — describing events that had not yet happened.',
    poster: p('echo15'), backdrop: b('echo15bg'),
    ageRating: 'PG-13', cast: ['Clio Marsh', 'Ari Sven', 'Peta Niles'], director: 'Elena Voss',
  },
  {
    id: 'm16', title: 'Nova Falls', type: 'movie', year: 2023,
    genre: ['Action', 'Drama'], rating: 7.4, duration: '1h 59m',
    description: 'A disgraced Olympic sprinter discovers a doping ring that goes all the way to the top of international sport — and learns she has been its unwitting centerpiece.',
    poster: p('nova16'), backdrop: b('nova16bg'),
    ageRating: 'PG-13', cast: ['Zola Amara', 'Ken Osei', 'Diana Cross'], director: 'Will Decker',
  },
  {
    id: 'm17', title: 'The Last Meridian', type: 'movie', year: 2023,
    genre: ['Epic', 'Drama'], rating: 8.8, duration: '3h 04m',
    description: 'Across three generations, a family of cartographers maps the unmappable — tracing borders that empires have risen and fallen trying to claim.',
    poster: p('meridian17'), backdrop: b('meridian17bg'),
    ageRating: 'PG-13', cast: ['Ioan Marin', 'Leila Hashemi', 'Nico Tanner', 'Clara Pont'], director: 'Rosa Almanza',
  },
  {
    id: 'm18', title: 'Phantom Frequency', type: 'movie', year: 2023,
    genre: ['Horror', 'Sci-Fi'], rating: 7.2, duration: '1h 46m',
    description: 'A pirate radio operator picks up a broadcast from a frequency that should be empty — and the voice on the other end knows exactly where she lives.',
    poster: p('phantom18'), backdrop: b('phantom18bg'),
    ageRating: 'R', cast: ['Mel Stark', 'Tom Hale', 'Ike Flores'], director: 'Donna Reed',
  },
  {
    id: 'm19', title: 'The Architect', type: 'movie', year: 2024,
    genre: ['Drama', 'Psychological'], rating: 8.9, duration: '2h 35m',
    description: 'A visionary architect\'s masterwork — a city designed to eliminate crime through environmental design — becomes the stage for the most meticulously planned murder in history.',
    poster: p('architect19'), backdrop: b('architect19bg'),
    ageRating: 'R', cast: ['August Rein', 'Simone Clare', 'Paulo Melo'], director: 'Petra Haus',
  },
  {
    id: 'm20', title: 'Ember Sky', type: 'movie', year: 2024,
    genre: ['Animation', 'Adventure'], rating: 8.0, duration: '1h 44m',
    description: 'A young cloud-shepherd must traverse a sky turned to ash after the sun goes cold — guided only by a map drawn in starlight by the last living astronomer.',
    poster: p('ember20'), backdrop: b('ember20bg'),
    ageRating: 'PG', cast: ['(voice) Lexi Day', '(voice) Finn Roo', '(voice) Opal Vane'], director: 'Milo Sage',
  },
];

export const allSeries: ContentItem[] = [
  {
    id: 's1', title: 'Nexus Protocol', type: 'series', year: 2024,
    genre: ['Sci-Fi', 'Thriller'], rating: 9.1, duration: '52m avg', seasons: 2, totalEpisodes: 16,
    description: 'Inside a classified government facility, a team of linguists decodes a signal that predates the formation of the solar system. Each episode peels back another layer of an impossibly vast conspiracy.',
    poster: p('nexus21'), backdrop: b('nexus21bg'),
    ageRating: 'TV-MA', cast: ['Asha Prime', 'Cal Drexler', 'Yuna Park', 'Tom Veil'], director: 'Eva Holtz',
    progress: 70,
  },
  {
    id: 's2', title: 'The Syndicate', type: 'series', year: 2021,
    genre: ['Crime', 'Drama'], rating: 8.7, duration: '48m avg', seasons: 4, totalEpisodes: 36,
    description: 'A dynastic crime family\'s stranglehold on a port city begins to crack when the youngest daughter returns from law school — intent on burning it all down from the inside.',
    poster: p('syndicate22'), backdrop: b('syndicate22bg'),
    ageRating: 'TV-MA', cast: ['Rosa Cane', 'Sal Ricci', 'Dani Morse', 'Eddie Cross'], director: 'Gio Manz',
  },
  {
    id: 's3', title: 'Orbital', type: 'series', year: 2024,
    genre: ['Sci-Fi', 'Drama'], rating: 8.4, duration: '55m avg', seasons: 1, totalEpisodes: 8,
    description: 'Life aboard the first permanent space habitat — told through the eyes of eight crew members from seven nations, all chosen for their skills and none of them ready for each other.',
    poster: p('orbital23'), backdrop: b('orbital23bg'),
    ageRating: 'TV-14', cast: ['Zara Ellis', 'Ren Sato', 'Ivan Krol', 'Amara Diop'], director: 'Stella Nord',
    progress: 45,
  },
  {
    id: 's4', title: 'Dark Frequency', type: 'series', year: 2023,
    genre: ['Horror', 'Mystery'], rating: 8.2, duration: '44m avg', seasons: 3, totalEpisodes: 24,
    description: 'Every five years, the same small town goes dark for exactly 24 hours. No one remembers what happens in the darkness — until one teenager starts writing it down.',
    poster: p('darkfreq24'), backdrop: b('darkfreq24bg'),
    ageRating: 'TV-MA', cast: ['Meg Wray', 'Cole Hess', 'Iris Dorn', 'Walt Finn'], director: 'Nadia Kress',
  },
  {
    id: 's5', title: 'The Obsidian Crown', type: 'series', year: 2023,
    genre: ['Fantasy', 'Epic'], rating: 8.9, duration: '62m avg', seasons: 2, totalEpisodes: 14,
    description: 'In a world where the night sky is a living map of power, three rival bloodlines wage war for control of the only artifact that can rewrite the stars.',
    poster: p('obsidian25'), backdrop: b('obsidian25bg'),
    ageRating: 'TV-MA', cast: ['Lyra Shade', 'Gareth Stone', 'Sena Gold', 'Bron Hale'], director: 'Ama Osei',
  },
  {
    id: 's6', title: 'Cipher', type: 'series', year: 2024,
    genre: ['Spy', 'Thriller'], rating: 8.5, duration: '47m avg', seasons: 2, totalEpisodes: 16,
    description: 'A double agent embedded in the world\'s most dangerous intelligence network begins to lose track of which side she is actually working for.',
    poster: p('cipher26'), backdrop: b('cipher26bg'),
    ageRating: 'TV-MA', cast: ['Zoe Lain', 'Marc Dahl', 'Su-Jin Cho'], director: 'Pedro Ruiz',
    progress: 20,
  },
  {
    id: 's7', title: 'Hollow Earth', type: 'series', year: 2023,
    genre: ['Adventure', 'Sci-Fi'], rating: 7.9, duration: '50m avg', seasons: 3, totalEpisodes: 27,
    description: 'A geological survey team drills deeper than any humans have gone before and finds a breathable atmosphere — and evidence of a civilization that never reached the surface.',
    poster: p('hollow27'), backdrop: b('hollow27bg'),
    ageRating: 'TV-14', cast: ['Ben Caves', 'Mia Stone', 'Joel Park', 'Frida Tern'], director: 'Kara Vos',
  },
  {
    id: 's8', title: 'The Signal', type: 'series', year: 2024,
    genre: ['Mystery', 'Drama'], rating: 9.0, duration: '53m avg', seasons: 1, totalEpisodes: 10,
    description: 'After a catastrophic bridge collapse, the survivors of the disaster find that they can communicate with each other through a frequency only they can hear — sharing each other\'s memories.',
    poster: p('signal28'), backdrop: b('signal28bg'),
    ageRating: 'TV-MA', cast: ['Kit Hale', 'Remi Voss', 'Cass Bell'], director: 'Lena Roth',
  },
  {
    id: 's9', title: 'Fracture Point', type: 'series', year: 2022,
    genre: ['Political', 'Thriller'], rating: 8.6, duration: '49m avg', seasons: 4, totalEpisodes: 40,
    description: 'Inside the chambers of a fractured democracy, a parliamentary aide discovers that the vote that saved the government was the one that destroyed it.',
    poster: p('fracture29'), backdrop: b('fracture29bg'),
    ageRating: 'TV-MA', cast: ['Alice Wren', 'Sam Cross', 'Paul Neri', 'Grace Dahl'], director: 'Carl Moser',
  },
  {
    id: 's10', title: 'Neon City', type: 'series', year: 2021,
    genre: ['Cyberpunk', 'Crime'], rating: 8.8, duration: '45m avg', seasons: 5, totalEpisodes: 50,
    description: 'A city detective with an illegally modified memory implant polices the streets of a sprawling neon megalopolis where every crime leaves a digital ghost.',
    poster: p('neoncity30'), backdrop: b('neoncity30bg'),
    ageRating: 'TV-MA', cast: ['Kai Dex', 'Nori Shen', 'Zack Holt', 'Lia Prime'], director: 'Ren Nakamura',
  },
  {
    id: 's11', title: 'Echoes', type: 'series', year: 2024,
    genre: ['Psychological', 'Drama'], rating: 8.3, duration: '51m avg', seasons: 2, totalEpisodes: 14,
    description: 'Identical twins have secretly been swapping lives since childhood. When one of them vanishes, the other must live both lives without letting anyone notice the difference.',
    poster: p('echoes31'), backdrop: b('echoes31bg'),
    ageRating: 'TV-MA', cast: ['Lea Fenn', 'Lea Fenn', 'Dan Moor', 'Cleo Renn'], director: 'Sara Blane',
  },
  {
    id: 's12', title: 'The Atlas War', type: 'series', year: 2023,
    genre: ['Historical', 'Epic'], rating: 8.7, duration: '68m avg', seasons: 3, totalEpisodes: 24,
    description: 'The untold story of five cartographers embedded with rival armies in the world\'s last great land war — mapping territory that disappeared as fast as they drew it.',
    poster: p('atlas32'), backdrop: b('atlas32bg'),
    ageRating: 'TV-MA', cast: ['Niall Forde', 'Aya Hassan', 'Bert Sol', 'Ona Gris'], director: 'Dmitri Volkov',
  },
  {
    id: 's13', title: 'Quantum Gate', type: 'series', year: 2024,
    genre: ['Sci-Fi', 'Adventure'], rating: 8.1, duration: '54m avg', seasons: 1, totalEpisodes: 8,
    description: 'An experimental particle accelerator doesn\'t just collide atoms — it opens doorways to alternate versions of Earth, each one more unstable than the last.',
    poster: p('quantum33'), backdrop: b('quantum33bg'),
    ageRating: 'TV-14', cast: ['Eli Trace', 'Mira Sol', 'Dorian Black'], director: 'Felix Wert',
  },
  {
    id: 's14', title: 'Shadow Protocol', type: 'series', year: 2024,
    genre: ['Spy', 'Action'], rating: 8.4, duration: '46m avg', seasons: 2, totalEpisodes: 18,
    description: 'A black-site operator is activated after a decade of dormancy to prevent the sale of a weapon that can silence every armed force on the planet simultaneously.',
    poster: p('shadow34'), backdrop: b('shadow34bg'),
    ageRating: 'TV-MA', cast: ['Axel Rade', 'Yoko Flynn', 'Max Dorn'], director: 'Ike Olu',
    progress: 55,
  },
  {
    id: 's15', title: 'Crimson Ward', type: 'series', year: 2022,
    genre: ['Medical', 'Drama'], rating: 8.0, duration: '43m avg', seasons: 6, totalEpisodes: 72,
    description: 'Inside a hospital serving the most dangerous neighbourhood on Earth, emergency doctors fight for lives while fighting each other — and the system that keeps failing both.',
    poster: p('crimward35'), backdrop: b('crimward35bg'),
    ageRating: 'TV-14', cast: ['Bea Holt', 'Santi Cruz', 'Joy Aduke', 'Nick Ren'], director: 'Clara Foss',
  },
];

export const featuredHero = movies[10]; // The Glass Theorem

export const continueWatching: ContentItem[] = [
  { ...movies[2], progress: 62 },
  { ...movies[4], progress: 35 },
  { ...movies[7], progress: 88 },
  { ...allSeries[0], progress: 70 },
  { ...allSeries[2], progress: 45 },
  { ...allSeries[5], progress: 20 },
  { ...allSeries[13], progress: 55 },
];

export const trending: ContentItem[] = [movies[10], movies[0], allSeries[0], movies[2], allSeries[7], movies[9], allSeries[4]];
export const popularMovies: ContentItem[] = [movies[0], movies[2], movies[9], movies[10], movies[6], movies[13], movies[14]];
export const popularSeries: ContentItem[] = [allSeries[0], allSeries[9], allSeries[4], allSeries[1], allSeries[7], allSeries[5]];
export const newReleases: ContentItem[] = [movies[14], movies[13], allSeries[12], movies[0], allSeries[0], movies[9]];
export const recommended: ContentItem[] = [allSeries[7], movies[18], allSeries[10], movies[11], allSeries[3], movies[3]];

export const channels: LiveChannel[] = [
  { id: 'c1', name: 'NEXUS News', category: 'News', currentProgram: 'Global Briefing', nextProgram: 'Market Watch', currentTime: '8:00 PM', thumbnail: b('ch1'), viewers: '1.2M', color: '#3b82f6' },
  { id: 'c2', name: 'Sport Central', category: 'Sports', currentProgram: 'Champions League', nextProgram: 'Highlights Desk', currentTime: '8:00 PM', thumbnail: b('ch2'), viewers: '3.4M', color: '#22c55e' },
  { id: 'c3', name: 'Cinema Prime', category: 'Movies', currentProgram: 'The Glass Theorem', nextProgram: 'Phantom Eclipse', currentTime: '8:00 PM', thumbnail: b('ch3'), viewers: '900K', color: '#f59e0b' },
  { id: 'c4', name: 'Vibe', category: 'Entertainment', currentProgram: 'Late Night with Dex', nextProgram: 'Pop Insider', currentTime: '8:00 PM', thumbnail: b('ch4'), viewers: '2.1M', color: '#ec4899' },
  { id: 'c5', name: 'Kids Zone', category: 'Kids', currentProgram: 'Ember Sky Movie', nextProgram: 'Stardust Gang', currentTime: '8:00 PM', thumbnail: b('ch5'), viewers: '850K', color: '#a78bfa' },
  { id: 'c6', name: 'Nature+', category: 'Documentary', currentProgram: 'Ocean Deep', nextProgram: 'Arctic Wild', currentTime: '8:00 PM', thumbnail: b('ch6'), viewers: '620K', color: '#14b8a6' },
  { id: 'c7', name: 'Globe Sports', category: 'Sports', currentProgram: 'Grand Slam Tennis', nextProgram: 'Formula Analysis', currentTime: '8:00 PM', thumbnail: b('ch7'), viewers: '1.8M', color: '#f97316' },
  { id: 'c8', name: 'Retro Cinema', category: 'Movies', currentProgram: 'Classic Marathon', nextProgram: 'The Directors Cut', currentTime: '8:00 PM', thumbnail: b('ch8'), viewers: '410K', color: '#6366f1' },
];

export const genres = ['All', 'Action', 'Comedy', 'Drama', 'Horror', 'Sci-Fi', 'Thriller', 'Animation', 'Crime', 'Romance', 'Documentary', 'Fantasy'];
