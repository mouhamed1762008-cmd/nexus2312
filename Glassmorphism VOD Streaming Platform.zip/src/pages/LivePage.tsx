import { useState } from 'react';
import { channels, NavigateFn } from '../data';

const CATEGORIES = ['All', 'News', 'Sports', 'Movies', 'Entertainment', 'Kids', 'Documentary'];

const EPG = [
  { channel: 'NEXUS News', now: 'Global Briefing', next: 'Market Watch', time: '8:00 PM' },
  { channel: 'Sport Central', now: 'Champions League', next: 'Highlights Desk', time: '8:00 PM' },
  { channel: 'Cinema Prime', now: 'The Glass Theorem', next: 'Phantom Eclipse', time: '8:00 PM' },
  { channel: 'Vibe', now: 'Late Night with Dex', next: 'Pop Insider', time: '8:00 PM' },
  { channel: 'Kids Zone', now: 'Ember Sky Movie', next: 'Stardust Gang', time: '8:00 PM' },
  { channel: 'Nature+', now: 'Ocean Deep', next: 'Arctic Wild', time: '8:00 PM' },
  { channel: 'Globe Sports', now: 'Grand Slam Tennis', next: 'Formula Analysis', time: '8:00 PM' },
  { channel: 'Retro Cinema', now: 'Classic Marathon', next: 'The Directors Cut', time: '8:00 PM' },
];

export default function LivePage({ navigate: _navigate }: { navigate: NavigateFn }) {
  const [activeCategory, setActiveCategory] = useState('All');
  const [activeChannel, setActiveChannel] = useState(channels[1]); // Sport Central featured

  const filtered = activeCategory === 'All'
    ? channels
    : channels.filter((c) => c.category === activeCategory);

  return (
    <div className="min-h-screen pt-20 pb-28 md:pb-8">
      {/* Featured player */}
      <div className="px-6 lg:px-12 mt-6">
        <div className="relative w-full aspect-video max-h-[480px] rounded-3xl overflow-hidden bg-black/80 border border-white/8 shadow-2xl">
          {/* Video thumbnail */}
          <img
            src={activeChannel.thumbnail}
            alt={activeChannel.currentProgram}
            className="absolute inset-0 w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

          {/* LIVE badge */}
          <div className="absolute top-5 left-5 flex items-center gap-2">
            <span className="flex items-center gap-1.5 bg-red-600 text-white text-xs font-black px-3 py-1.5 rounded-full">
              <span className="w-2 h-2 rounded-full bg-white live-dot" />
              LIVE
            </span>
            <span className="bg-black/50 backdrop-blur-sm text-white/80 text-xs font-semibold px-3 py-1.5 rounded-full border border-white/10">
              {activeChannel.viewers} watching
            </span>
          </div>

          {/* Channel info overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <div className="flex items-end justify-between">
              <div>
                <div className="text-white/50 text-sm font-semibold mb-1 uppercase tracking-wider">
                  {activeChannel.category}
                </div>
                <h2 className="text-white font-black text-2xl md:text-4xl mb-1">
                  {activeChannel.currentProgram}
                </h2>
                <p className="text-white/60 text-sm">
                  on <span className="text-white font-semibold">{activeChannel.name}</span>
                </p>
              </div>
              {/* Play button */}
              <button className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-xl border border-white/20 flex items-center justify-center hover:bg-white/30 transition-all hover:scale-105">
                <svg className="w-7 h-7 fill-white ml-1" viewBox="0 0 24 24">
                  <path d="M5 3l14 9-14 9V3z" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Category filter */}
      <div className="px-6 lg:px-12 mt-8 mb-6">
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`flex-none px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 ${
                activeCategory === cat
                  ? 'bg-gradient-to-r from-blue-500 to-violet-600 text-white'
                  : 'bg-white/6 border border-white/8 text-white/60 hover:bg-white/10 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Channel grid */}
      <div className="px-6 lg:px-12 mb-12">
        <h2 className="text-xl font-bold text-white mb-5">Live Channels</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filtered.map((channel) => {
            const isActive = activeChannel.id === channel.id;
            return (
              <button
                key={channel.id}
                onClick={() => setActiveChannel(channel)}
                className={`relative rounded-2xl overflow-hidden group text-left transition-all duration-300 ${
                  isActive
                    ? 'ring-2 ring-blue-500/70 shadow-lg shadow-blue-500/20 scale-[1.02]'
                    : 'hover:scale-[1.02] hover:ring-1 hover:ring-white/20'
                }`}
              >
                <div className="aspect-video relative">
                  <img
                    src={channel.thumbnail}
                    alt={channel.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-2.5 left-2.5 flex items-center gap-1 bg-red-600/90 text-white text-[10px] font-black px-2 py-0.5 rounded-full">
                    <span className="w-1.5 h-1.5 rounded-full bg-white live-dot" />
                    LIVE
                  </div>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-3">
                  <p className="text-white font-bold text-sm truncate">{channel.name}</p>
                  <p className="text-white/60 text-xs truncate mt-0.5">{channel.currentProgram}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* EPG - Electronic Program Guide */}
      <div className="px-6 lg:px-12">
        <h2 className="text-xl font-bold text-white mb-5">Program Guide</h2>
        <div className="rounded-3xl bg-white/4 backdrop-blur-xl border border-white/8 overflow-hidden">
          {/* EPG header */}
          <div className="grid grid-cols-4 px-6 py-3 bg-white/4 border-b border-white/6">
            <span className="text-white/50 text-xs font-bold uppercase tracking-wider">Channel</span>
            <span className="text-white/50 text-xs font-bold uppercase tracking-wider">Now</span>
            <span className="text-white/50 text-xs font-bold uppercase tracking-wider">Next</span>
            <span className="text-white/50 text-xs font-bold uppercase tracking-wider text-right">Time</span>
          </div>
          {/* EPG rows */}
          {EPG.map((row, i) => (
            <div
              key={i}
              className="grid grid-cols-4 items-center px-6 py-4 border-b border-white/4 last:border-0 hover:bg-white/4 transition-colors cursor-pointer group"
            >
              <span className="text-white font-semibold text-sm truncate pr-4">{row.channel}</span>
              <span className="text-blue-300 font-medium text-sm truncate pr-4">{row.now}</span>
              <span className="text-white/50 text-sm truncate pr-4">{row.next}</span>
              <span className="text-white/40 text-xs font-mono text-right">{row.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
