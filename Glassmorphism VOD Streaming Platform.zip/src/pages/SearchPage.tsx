import { useState, useMemo } from 'react';
import { movies, allSeries, genres, NavigateFn, ContentItem } from '../data';
import { ContentCard, StarRating } from '../components';

const ALL_CONTENT = [...movies, ...allSeries];

const YEARS = ['All Years', '2024', '2023', '2022', '2021'];
const RATINGS = ['All Ratings', '9+', '8+', '7+'];

export default function SearchPage({ navigate }: { navigate: NavigateFn }) {
  const [query, setQuery] = useState('');
  const [activeType, setActiveType] = useState<'All' | 'Movies' | 'Series'>('All');
  const [activeGenre, setActiveGenre] = useState('All');
  const [activeYear, setActiveYear] = useState('All Years');
  const [activeRating, setActiveRating] = useState('All Ratings');

  const results = useMemo(() => {
    let items: ContentItem[] = ALL_CONTENT;
    if (activeType === 'Movies') items = movies;
    else if (activeType === 'Series') items = allSeries;
    if (activeGenre !== 'All') items = items.filter((i) => i.genre.includes(activeGenre));
    if (activeYear !== 'All Years') items = items.filter((i) => String(i.year) === activeYear);
    if (activeRating !== 'All Ratings') {
      const min = parseFloat(activeRating.replace('+', ''));
      items = items.filter((i) => i.rating >= min);
    }
    if (query.trim()) {
      const q = query.toLowerCase();
      items = items.filter(
        (i) =>
          i.title.toLowerCase().includes(q) ||
          i.genre.some((g) => g.toLowerCase().includes(q)) ||
          i.cast.some((c) => c.toLowerCase().includes(q)) ||
          i.director.toLowerCase().includes(q)
      );
    }
    return items;
  }, [query, activeType, activeGenre, activeYear, activeRating]);

  return (
    <div className="min-h-screen pt-20 pb-28 md:pb-8 px-6 lg:px-12">
      {/* Search header */}
      <div className="max-w-2xl mx-auto mt-8 mb-10">
        <h1 className="text-3xl font-black text-white mb-6 text-center">Search</h1>
        <div className="relative">
          <svg
            className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40"
            fill="none"
            stroke="currentColor"
            strokeWidth={2}
            viewBox="0 0 24 24"
          >
            <circle cx="11" cy="11" r="8" />
            <path d="m21 21-4.35-4.35" />
          </svg>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search movies, series, actors..."
            className="w-full pl-12 pr-5 py-4 rounded-2xl bg-white/6 backdrop-blur-xl border border-white/10 text-white placeholder-white/30 focus:outline-none focus:border-blue-400/60 focus:bg-white/10 transition-all duration-200 text-base"
            autoFocus
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-white/40 hover:text-white transition-colors"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="space-y-4 mb-8">
        {/* Type filter */}
        <div className="flex gap-2">
          {(['All', 'Movies', 'Series'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setActiveType(t)}
              className={`px-5 py-2.5 rounded-xl text-sm font-bold transition-all duration-200 ${
                activeType === t
                  ? 'bg-gradient-to-r from-blue-500 to-violet-600 text-white shadow-md shadow-blue-500/25'
                  : 'bg-white/6 border border-white/8 text-white/60 hover:bg-white/10 hover:text-white'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {/* Genre / Year / Rating */}
        <div className="flex flex-wrap gap-2">
          <select
            value={activeGenre}
            onChange={(e) => setActiveGenre(e.target.value)}
            className="px-4 py-2 rounded-xl bg-white/6 border border-white/8 text-white/70 text-sm focus:outline-none focus:border-blue-400/50 cursor-pointer"
          >
            {['All', ...genres.slice(1)].map((g) => (
              <option key={g} value={g} className="bg-[#0d0d1a]">{g}</option>
            ))}
          </select>
          <select
            value={activeYear}
            onChange={(e) => setActiveYear(e.target.value)}
            className="px-4 py-2 rounded-xl bg-white/6 border border-white/8 text-white/70 text-sm focus:outline-none focus:border-blue-400/50 cursor-pointer"
          >
            {YEARS.map((y) => (
              <option key={y} value={y} className="bg-[#0d0d1a]">{y}</option>
            ))}
          </select>
          <select
            value={activeRating}
            onChange={(e) => setActiveRating(e.target.value)}
            className="px-4 py-2 rounded-xl bg-white/6 border border-white/8 text-white/70 text-sm focus:outline-none focus:border-blue-400/50 cursor-pointer"
          >
            {RATINGS.map((r) => (
              <option key={r} value={r} className="bg-[#0d0d1a]">{r}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Results count */}
      <p className="text-white/40 text-sm font-medium mb-6">
        {results.length} result{results.length !== 1 ? 's' : ''}
        {query && ` for "${query}"`}
      </p>

      {/* Results grid */}
      {results.length > 0 ? (
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-4">
          {results.map((item) => (
            <ContentCard key={item.id} item={item} navigate={navigate} size="sm" />
          ))}
        </div>
      ) : (
        /* Empty state */
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <div className="w-20 h-20 rounded-3xl bg-white/5 border border-white/8 flex items-center justify-center mb-6">
            <svg className="w-10 h-10 text-white/20" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24">
              <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
            </svg>
          </div>
          <h3 className="text-white font-bold text-xl mb-2">No results found</h3>
          <p className="text-white/40 text-sm max-w-xs">
            Try a different search term, or adjust your filters to discover more content.
          </p>
        </div>
      )}
    </div>
  );
}
