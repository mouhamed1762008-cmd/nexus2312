import { useState, useMemo } from 'react';
import { movies, genres, NavigateFn } from '../data';
import { HeroSection, ContentCard, GenreFilter } from '../components';

const SORT_OPTIONS = ['Trending', 'Rating', 'Newest', 'A–Z'];

export default function MoviesPage({ navigate }: { navigate: NavigateFn }) {
  const [activeGenre, setActiveGenre] = useState('All');
  const [sort, setSort] = useState('Trending');

  const heroMovie = movies[10]; // The Glass Theorem

  const filtered = useMemo(() => {
    let items = activeGenre === 'All' ? [...movies] : movies.filter((m) => m.genre.includes(activeGenre));
    if (sort === 'Rating') items.sort((a, b) => b.rating - a.rating);
    else if (sort === 'Newest') items.sort((a, b) => b.year - a.year);
    else if (sort === 'A–Z') items.sort((a, b) => a.title.localeCompare(b.title));
    return items;
  }, [activeGenre, sort]);

  const sections = [
    { title: 'Trending', items: movies.slice(0, 7) },
    { title: 'New Releases', items: movies.slice(13, 20) },
    { title: 'Top Rated', items: [...movies].sort((a, b) => b.rating - a.rating).slice(0, 7) },
    { title: 'Action & Adventure', items: movies.filter((m) => m.genre.includes('Action')).slice(0, 7) },
    { title: 'Sci-Fi', items: movies.filter((m) => m.genre.includes('Sci-Fi')).slice(0, 7) },
    { title: 'Thriller & Mystery', items: movies.filter((m) => m.genre.some((g) => ['Thriller', 'Mystery'].includes(g))).slice(0, 7) },
  ];

  return (
    <div className="min-h-screen pb-28 md:pb-8">
      {/* Hero */}
      <HeroSection item={heroMovie} navigate={navigate} height="medium" />

      {/* Featured carousels */}
      <div className="mt-8 space-y-0">
        {sections.map((sec) =>
          sec.items.length === 0 ? null : (
            <section key={sec.title} className="mb-12">
              <div className="flex items-center justify-between mb-4 px-6 lg:px-12">
                <h2 className="text-lg md:text-xl font-bold text-white">{sec.title}</h2>
                <button className="text-sm text-blue-400 hover:text-blue-300 transition-colors font-medium">
                  View all →
                </button>
              </div>
              <div className="flex gap-4 overflow-x-auto pb-3 px-6 lg:px-12 scrollbar-hide">
                {sec.items.map((item) => (
                  <ContentCard key={item.id} item={item} navigate={navigate} />
                ))}
              </div>
            </section>
          )
        )}
      </div>

      {/* Browse all with filters */}
      <div className="px-6 lg:px-12 mt-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black text-white">All Movies</h2>
          <div className="flex items-center gap-2">
            <span className="text-white/40 text-sm hidden md:block">Sort:</span>
            <div className="flex gap-1">
              {SORT_OPTIONS.map((opt) => (
                <button
                  key={opt}
                  onClick={() => setSort(opt)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    sort === opt
                      ? 'bg-blue-500/20 border border-blue-500/40 text-blue-300'
                      : 'bg-white/5 border border-white/8 text-white/50 hover:text-white'
                  }`}
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="mb-6">
          <GenreFilter genres={genres} active={activeGenre} onChange={setActiveGenre} />
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 gap-4">
          {filtered.map((item) => (
            <ContentCard key={item.id} item={item} navigate={navigate} size="sm" />
          ))}
        </div>
      </div>
    </div>
  );
}
