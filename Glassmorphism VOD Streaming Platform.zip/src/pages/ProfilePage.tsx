import { useState } from 'react';
import { NavigateFn, continueWatching, popularMovies } from '../data';
import { ContentCard } from '../components';

const FAVORITE_GENRES = ['Sci-Fi', 'Thriller', 'Drama', 'Action', 'Mystery'];
const LANGUAGES = ['English', 'Spanish', 'French', 'German', 'Arabic', 'Japanese', 'Korean'];
const SUBTITLE_LANGS = ['Off', 'English', 'Spanish', 'French', 'Arabic'];
const THEMES = ['Dark (default)', 'Midnight', 'Cinema', 'Navy'];
const SPEEDS = ['0.5×', '0.75×', '1×', '1.25×', '1.5×', '2×'];

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-3xl bg-white/4 backdrop-blur-xl border border-white/8 p-6">
      <h3 className="font-black text-white text-lg mb-5">{title}</h3>
      {children}
    </div>
  );
}

function SettingRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-white/5 last:border-0">
      <span className="text-white/60 text-sm font-medium">{label}</span>
      <div className="flex items-center gap-3">{children}</div>
    </div>
  );
}

export default function ProfilePage({
  navigate,
  userName,
}: {
  navigate: NavigateFn;
  userName: string;
}) {
  const [editMode, setEditMode] = useState(false);
  const [displayName, setDisplayName] = useState(userName || 'Viewer');
  const [language, setLanguage] = useState('English');
  const [subtitles, setSubtitles] = useState('Off');
  const [autoplay, setAutoplay] = useState(true);
  const [autoSkip, setAutoSkip] = useState(true);
  const [theme, setTheme] = useState('Dark (default)');
  const [speed, setSpeed] = useState('1×');
  const [activeTab, setActiveTab] = useState<'overview' | 'list' | 'history' | 'settings'>('overview');

  const initials = displayName.slice(0, 2).toUpperCase();

  return (
    <div className="min-h-screen pt-20 pb-28 md:pb-12 px-6 lg:px-12">
      {/* Profile header card */}
      <div className="mt-6 rounded-3xl bg-white/4 backdrop-blur-xl border border-white/8 p-6 md:p-8 relative overflow-hidden mb-8">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 via-transparent to-violet-600/10 pointer-events-none" />
        <div className="relative flex flex-col md:flex-row items-start md:items-center gap-6">
          {/* Avatar */}
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-blue-500 to-violet-600 flex items-center justify-center text-white text-3xl font-black shadow-2xl shadow-blue-500/30 flex-shrink-0">
            {initials}
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            {editMode ? (
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="text-3xl font-black bg-transparent border-b border-blue-500/50 text-white focus:outline-none mb-2 w-full max-w-xs"
              />
            ) : (
              <h1 className="text-3xl font-black text-white mb-1">{displayName}</h1>
            )}
            <p className="text-white/40 text-sm mb-3">nexus@example.com · Premium Plan</p>
            <div className="flex flex-wrap gap-3">
              <div className="px-4 py-2 rounded-xl bg-white/6 border border-white/8">
                <span className="text-white font-black text-lg">247</span>
                <span className="text-white/40 text-xs ml-1">Watched</span>
              </div>
              <div className="px-4 py-2 rounded-xl bg-white/6 border border-white/8">
                <span className="text-white font-black text-lg">34</span>
                <span className="text-white/40 text-xs ml-1">My List</span>
              </div>
              <div className="px-4 py-2 rounded-xl bg-white/6 border border-white/8">
                <span className="text-white font-black text-lg">1,240</span>
                <span className="text-white/40 text-xs ml-1">Hours</span>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex gap-2 flex-shrink-0">
            <button
              onClick={() => setEditMode(!editMode)}
              className="px-5 py-2.5 rounded-xl bg-white/8 border border-white/12 text-white text-sm font-semibold hover:bg-white/15 transition-all"
            >
              {editMode ? 'Save' : 'Edit Profile'}
            </button>
            <button
              onClick={() => navigate('welcome')}
              className="px-5 py-2.5 rounded-xl bg-red-500/15 border border-red-500/25 text-red-400 text-sm font-semibold hover:bg-red-500/25 transition-all"
            >
              Sign Out
            </button>
          </div>
        </div>
      </div>

      {/* Tab navigation */}
      <div className="flex gap-2 mb-8 overflow-x-auto scrollbar-hide pb-1">
        {(['overview', 'list', 'history', 'settings'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-none px-5 py-2.5 rounded-xl text-sm font-bold transition-all capitalize ${
              activeTab === tab
                ? 'bg-gradient-to-r from-blue-500 to-violet-600 text-white shadow-md shadow-blue-500/25'
                : 'bg-white/6 border border-white/8 text-white/60 hover:text-white hover:bg-white/10'
            }`}
          >
            {tab === 'list' ? 'My List' : tab === 'history' ? 'Watch History' : tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Tab: Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Continue watching */}
          <div>
            <h2 className="text-xl font-bold text-white mb-4">Continue Watching</h2>
            <div className="flex gap-4 overflow-x-auto pb-3 scrollbar-hide">
              {continueWatching.map((item) => (
                <ContentCard key={item.id} item={item} navigate={navigate} />
              ))}
            </div>
          </div>

          {/* Favorite genres */}
          <Panel title="Favorite Genres">
            <div className="flex flex-wrap gap-3">
              {FAVORITE_GENRES.map((g) => (
                <span key={g} className="px-4 py-2 rounded-full bg-blue-500/15 border border-blue-500/25 text-blue-300 text-sm font-semibold">
                  {g}
                </span>
              ))}
              <button className="px-4 py-2 rounded-full bg-white/6 border border-white/10 text-white/50 text-sm font-semibold hover:bg-white/10 hover:text-white transition-colors">
                + Add Genre
              </button>
            </div>
          </Panel>
        </div>
      )}

      {/* Tab: My List */}
      {activeTab === 'list' && (
        <div>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7 gap-4">
            {popularMovies.map((item) => (
              <ContentCard key={item.id} item={item} navigate={navigate} size="sm" />
            ))}
          </div>
        </div>
      )}

      {/* Tab: Watch History */}
      {activeTab === 'history' && (
        <div className="space-y-3">
          {continueWatching.map((item, i) => (
            <button
              key={item.id}
              onClick={() => navigate('details', item)}
              className="w-full flex items-center gap-4 p-4 rounded-2xl bg-white/4 border border-white/7 hover:bg-white/8 transition-all group text-left"
            >
              <div className="w-16 flex-none rounded-xl overflow-hidden">
                <img src={item.poster} alt={item.title} className="w-full aspect-[2/3] object-cover group-hover:scale-105 transition-transform" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-white text-sm mb-0.5">{item.title}</p>
                <p className="text-white/40 text-xs mb-2">{item.year} · {item.duration}</p>
                <div className="h-1 rounded-full bg-white/10 max-w-48">
                  <div className="h-full bg-gradient-to-r from-blue-500 to-violet-500 rounded-full"
                    style={{ width: `${item.progress ?? 0}%` }} />
                </div>
                <p className="text-white/30 text-xs mt-1">{item.progress ?? 0}% watched</p>
              </div>
              <span className="text-white/30 text-xs flex-none">{3 + i}d ago</span>
            </button>
          ))}
        </div>
      )}

      {/* Tab: Settings */}
      {activeTab === 'settings' && (
        <div className="space-y-6">
          <Panel title="Account">
            <SettingRow label="Display Name">
              <span className="text-white font-semibold text-sm">{displayName}</span>
            </SettingRow>
            <SettingRow label="Email">
              <span className="text-white/60 text-sm">nexus@example.com</span>
            </SettingRow>
            <SettingRow label="Plan">
              <span className="px-3 py-1 rounded-full bg-blue-500/20 border border-blue-500/30 text-blue-300 text-xs font-bold">Premium</span>
            </SettingRow>
          </Panel>

          <Panel title="Playback">
            <SettingRow label="Autoplay Next Episode">
              <button onClick={() => setAutoplay(!autoplay)}
                className={`w-12 h-6 rounded-full transition-all duration-300 ${autoplay ? 'bg-blue-500' : 'bg-white/15'} relative flex-shrink-0`}>
                <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all duration-300 ${autoplay ? 'left-6' : 'left-0.5'}`} />
              </button>
            </SettingRow>
            <SettingRow label="Auto-Skip Intros">
              <button onClick={() => setAutoSkip(!autoSkip)}
                className={`w-12 h-6 rounded-full transition-all duration-300 ${autoSkip ? 'bg-blue-500' : 'bg-white/15'} relative flex-shrink-0`}>
                <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all duration-300 ${autoSkip ? 'left-6' : 'left-0.5'}`} />
              </button>
            </SettingRow>
            <SettingRow label="Playback Speed">
              <select value={speed} onChange={(e) => setSpeed(e.target.value)}
                className="bg-white/6 border border-white/10 text-white text-sm px-3 py-1.5 rounded-xl focus:outline-none cursor-pointer">
                {SPEEDS.map((s) => <option key={s} value={s} className="bg-[#0d0d1a]">{s}</option>)}
              </select>
            </SettingRow>
          </Panel>

          <Panel title="Language & Subtitles">
            <SettingRow label="Audio Language">
              <select value={language} onChange={(e) => setLanguage(e.target.value)}
                className="bg-white/6 border border-white/10 text-white text-sm px-3 py-1.5 rounded-xl focus:outline-none cursor-pointer">
                {LANGUAGES.map((l) => <option key={l} value={l} className="bg-[#0d0d1a]">{l}</option>)}
              </select>
            </SettingRow>
            <SettingRow label="Subtitles">
              <select value={subtitles} onChange={(e) => setSubtitles(e.target.value)}
                className="bg-white/6 border border-white/10 text-white text-sm px-3 py-1.5 rounded-xl focus:outline-none cursor-pointer">
                {SUBTITLE_LANGS.map((l) => <option key={l} value={l} className="bg-[#0d0d1a]">{l}</option>)}
              </select>
            </SettingRow>
          </Panel>

          <Panel title="Appearance">
            <SettingRow label="Theme">
              <select value={theme} onChange={(e) => setTheme(e.target.value)}
                className="bg-white/6 border border-white/10 text-white text-sm px-3 py-1.5 rounded-xl focus:outline-none cursor-pointer">
                {THEMES.map((t) => <option key={t} value={t} className="bg-[#0d0d1a]">{t}</option>)}
              </select>
            </SettingRow>
          </Panel>
        </div>
      )}
    </div>
  );
}
