import { useState, useEffect } from 'react';
import { ContentItem, NavigateFn, movies, allSeries } from '../data';

function IconBtn({ children, onClick, className = '' }: { children: React.ReactNode; onClick?: () => void; className?: string }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center justify-center rounded-xl hover:bg-white/10 transition-colors p-2 text-white/80 hover:text-white ${className}`}
    >
      {children}
    </button>
  );
}

export default function PlayerPage({
  item,
  navigate,
}: {
  item: ContentItem | null;
  navigate: NavigateFn;
}) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(23);
  const [volume, setVolume] = useState(80);
  const [showControls, setShowControls] = useState(true);
  const [quality, setQuality] = useState('1080p');
  const [subtitles, setSubtitles] = useState('Off');
  const [showQMenu, setShowQMenu] = useState(false);
  const [showSMenu, setShowSMenu] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    if (!isPlaying) return;
    const iv = setInterval(() => setProgress((p) => Math.min(p + 0.1, 100)), 800);
    return () => clearInterval(iv);
  }, [isPlaying]);

  useEffect(() => {
    if (!showControls) return;
    const t = setTimeout(() => { if (isPlaying) setShowControls(false); }, 3000);
    return () => clearTimeout(t);
  }, [showControls, isPlaying]);

  if (!item) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-white/50">No content selected.</p>
      </div>
    );
  }

  const totalSeconds = item.type === 'movie' ? 138 * 60 : 52 * 60;
  const elapsed = Math.round((progress / 100) * totalSeconds);
  const fmt = (s: number) => `${Math.floor(s / 60).toString().padStart(2, '0')}:${(s % 60).toString().padStart(2, '0')}`;

  const recommended = item.type === 'movie'
    ? movies.filter((m) => m.id !== item.id).slice(0, 6)
    : allSeries.filter((s) => s.id !== item.id).slice(0, 6);

  return (
    <div className="min-h-screen bg-black flex flex-col">
      {/* Player area */}
      <div
        className="relative w-full bg-black cursor-pointer"
        style={{ aspectRatio: '16/9', maxHeight: '80vh' }}
        onMouseMove={() => setShowControls(true)}
        onClick={() => { setIsPlaying(!isPlaying); setShowControls(true); }}
      >
        {/* Video bg */}
        <img
          src={item.backdrop}
          alt={item.title}
          className="absolute inset-0 w-full h-full object-cover opacity-80"
        />
        <div className="absolute inset-0 bg-black/20" />

        {/* Back button */}
        <div
          className={`absolute top-6 left-6 z-20 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}
        >
          <button
            onClick={(e) => { e.stopPropagation(); navigate(item.type === 'movie' ? 'details' : 'details', item); }}
            className="flex items-center gap-2 text-white/80 hover:text-white text-sm font-semibold bg-black/40 backdrop-blur-sm px-4 py-2 rounded-xl border border-white/10 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
              <path d="m15 18-6-6 6-6" />
            </svg>
            Back
          </button>
        </div>

        {/* Title overlay */}
        <div
          className={`absolute top-6 left-1/2 -translate-x-1/2 text-center transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}
        >
          <p className="text-white font-bold text-base md:text-lg drop-shadow-lg">{item.title}</p>
          {item.type === 'series' && <p className="text-white/60 text-xs mt-0.5">Season 1 · Episode 1</p>}
        </div>

        {/* Center play/pause */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div
            className={`w-20 h-20 rounded-full bg-white/15 backdrop-blur-sm border border-white/20 flex items-center justify-center transition-all duration-300 ${
              isPlaying ? 'opacity-0 scale-90' : 'opacity-100 scale-100'
            }`}
          >
            <svg className="w-9 h-9 fill-white ml-1.5" viewBox="0 0 24 24">
              <path d="M5 3l14 9-14 9V3z" />
            </svg>
          </div>
        </div>

        {/* Controls bar */}
        <div
          className={`absolute bottom-0 left-0 right-0 z-20 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="bg-gradient-to-t from-black via-black/60 to-transparent px-6 pt-10 pb-5">
            {/* Timeline */}
            <div className="flex items-center gap-3 mb-4">
              <span className="text-white/60 text-xs font-mono w-12 flex-none text-right">{fmt(elapsed)}</span>
              <div className="flex-1 relative h-1 rounded-full bg-white/15 group cursor-pointer"
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  setProgress(((e.clientX - rect.left) / rect.width) * 100);
                }}
              >
                <div
                  className="absolute left-0 top-0 h-full bg-gradient-to-r from-blue-500 to-violet-500 rounded-full"
                  style={{ width: `${progress}%` }}
                />
                <div
                  className="absolute top-1/2 -translate-y-1/2 w-3.5 h-3.5 rounded-full bg-white shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ left: `calc(${progress}% - 7px)` }}
                />
              </div>
              <span className="text-white/60 text-xs font-mono w-12 flex-none">{fmt(totalSeconds)}</span>
            </div>

            {/* Controls row */}
            <div className="flex items-center justify-between">
              {/* Left controls */}
              <div className="flex items-center gap-1">
                {/* Skip back */}
                <IconBtn onClick={() => setProgress(p => Math.max(0, p - 2))}>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                    <polyline points="1 4 1 10 7 10" />
                    <path d="M3.51 15a9 9 0 1 0 .49-3.27" />
                    <text x="8" y="16" className="text-[8px]" fill="currentColor" stroke="none">10</text>
                  </svg>
                </IconBtn>
                {/* Play/Pause */}
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="w-11 h-11 rounded-2xl bg-white/15 hover:bg-white/25 border border-white/15 flex items-center justify-center transition-all"
                >
                  {isPlaying ? (
                    <svg className="w-5 h-5 fill-white" viewBox="0 0 24 24">
                      <rect x="6" y="4" width="4" height="16" /><rect x="14" y="4" width="4" height="16" />
                    </svg>
                  ) : (
                    <svg className="w-5 h-5 fill-white ml-0.5" viewBox="0 0 24 24">
                      <path d="M5 3l14 9-14 9V3z" />
                    </svg>
                  )}
                </button>
                {/* Skip forward */}
                <IconBtn onClick={() => setProgress(p => Math.min(100, p + 2))}>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                    <polyline points="23 4 23 10 17 10" />
                    <path d="M20.49 15a9 9 0 1 1-.49-3.27" />
                  </svg>
                </IconBtn>
                {/* Volume */}
                <IconBtn onClick={() => setIsMuted(!isMuted)}>
                  {isMuted || volume === 0 ? (
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                      <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" /><line x1="23" y1="9" x2="17" y2="15" /><line x1="17" y1="9" x2="23" y2="15" />
                    </svg>
                  ) : (
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                      <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" /><path d="M15.54 8.46a5 5 0 0 1 0 7.07" /><path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
                    </svg>
                  )}
                </IconBtn>
                <div className="hidden md:block w-24">
                  <input
                    type="range" min={0} max={100} value={isMuted ? 0 : volume}
                    onChange={(e) => { setVolume(+e.target.value); setIsMuted(false); }}
                    className="w-full accent-blue-500"
                  />
                </div>
              </div>

              {/* Right controls */}
              <div className="flex items-center gap-1">
                {/* Subtitles */}
                <div className="relative">
                  <IconBtn onClick={() => { setShowSMenu(!showSMenu); setShowQMenu(false); }}>
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                      <rect x="2" y="4" width="20" height="16" rx="2" />
                      <path d="M7 15h4m-4-4h10" />
                    </svg>
                  </IconBtn>
                  {showSMenu && (
                    <div className="absolute bottom-12 right-0 bg-black/90 backdrop-blur-xl border border-white/10 rounded-2xl py-2 w-36 shadow-2xl">
                      {['Off', 'English', 'Spanish', 'French', 'Arabic'].map((opt) => (
                        <button key={opt} onClick={() => { setSubtitles(opt); setShowSMenu(false); }}
                          className={`w-full px-4 py-2 text-sm text-left transition-colors ${subtitles === opt ? 'text-blue-400 font-semibold' : 'text-white/70 hover:text-white'}`}>
                          {opt}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Quality */}
                <div className="relative">
                  <button onClick={() => { setShowQMenu(!showQMenu); setShowSMenu(false); }}
                    className="px-3 py-1.5 rounded-xl bg-white/10 border border-white/15 text-white text-xs font-bold hover:bg-white/20 transition-colors">
                    {quality}
                  </button>
                  {showQMenu && (
                    <div className="absolute bottom-12 right-0 bg-black/90 backdrop-blur-xl border border-white/10 rounded-2xl py-2 w-28 shadow-2xl">
                      {['4K', '1080p', '720p', '480p'].map((q) => (
                        <button key={q} onClick={() => { setQuality(q); setShowQMenu(false); }}
                          className={`w-full px-4 py-2 text-sm text-left transition-colors ${quality === q ? 'text-blue-400 font-semibold' : 'text-white/70 hover:text-white'}`}>
                          {q}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* PiP */}
                <IconBtn>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                    <rect x="2" y="3" width="20" height="14" rx="2" /><rect x="12" y="10" width="9" height="6" rx="1" />
                  </svg>
                </IconBtn>

                {/* Fullscreen */}
                <IconBtn>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                    <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" />
                  </svg>
                </IconBtn>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Below player */}
      <div className="bg-[#05050a] flex-1 px-6 lg:px-12 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Title + description */}
          <div className="flex-1">
            <h1 className="text-2xl md:text-3xl font-black text-white mb-2">{item.title}</h1>
            {item.type === 'series' && (
              <p className="text-blue-400 font-semibold text-sm mb-3">Season 1 · Episode 1 · 52 min</p>
            )}
            <div className="flex items-center gap-4 mb-4">
              <span className="text-amber-400 font-semibold text-sm">★ {item.rating}</span>
              <span className="text-white/50 text-sm">{item.year}</span>
              <span className="text-white/50 text-sm">{item.duration}</span>
            </div>
            <p className="text-white/60 leading-relaxed text-sm max-w-2xl">{item.description}</p>
          </div>

          {/* Up next (series only) */}
          {item.type === 'series' && (
            <div className="md:w-80">
              <h3 className="text-white font-bold text-base mb-3">Up Next</h3>
              <div className="space-y-3">
                {[2, 3].map((n) => (
                  <button
                    key={n}
                    onClick={() => navigate('player', item)}
                    className="flex gap-3 items-center w-full rounded-2xl bg-white/4 border border-white/7 p-3 hover:bg-white/8 transition-all group text-left"
                  >
                    <div className="w-24 flex-none rounded-xl overflow-hidden">
                      <img
                        src={`https://picsum.photos/seed/${item.id}ep${n}/320/180`}
                        alt=""
                        className="w-full aspect-video object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <div>
                      <p className="text-white font-semibold text-xs mb-0.5">Episode {n}</p>
                      <p className="text-white/40 text-xs">{item.duration}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Recommended */}
        <div className="mt-10">
          <h2 className="text-xl font-bold text-white mb-5">Recommended</h2>
          <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
            {recommended.map((r) => (
              <div key={r.id} className="flex-none w-36 md:w-44 group cursor-pointer" onClick={() => navigate('player', r)}>
                <div className="rounded-2xl overflow-hidden border border-white/8 relative">
                  <img src={r.poster} alt={r.title} className="w-full aspect-[2/3] object-cover group-hover:scale-105 transition-transform" />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <svg className="w-10 h-10 fill-white" viewBox="0 0 24 24"><path d="M5 3l14 9-14 9V3z" /></svg>
                  </div>
                </div>
                <p className="mt-2 text-xs text-white/60 font-medium truncate">{r.title}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
