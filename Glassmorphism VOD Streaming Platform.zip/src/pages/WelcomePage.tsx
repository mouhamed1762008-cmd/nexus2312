import { useState } from 'react';
import { movies } from '../data';

export default function WelcomePage({ onContinue }: { onContinue: (name: string) => void }) {
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) onContinue(name.trim());
  };

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden bg-base">
      {/* Blurred movie art collage background */}
      <div className="absolute inset-0 grid grid-cols-4 md:grid-cols-6 grid-rows-3 gap-1 opacity-25 scale-110">
        {movies.slice(0, 18).map((m, i) => (
          <img
            key={i}
            src={m.backdrop}
            alt=""
            className="w-full h-full object-cover"
          />
        ))}
      </div>
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-base/80 backdrop-blur-2xl" />

      {/* Ambient blobs */}
      <div className="absolute top-0 left-1/4 w-[600px] h-[600px] rounded-full bg-blue-600/15 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] rounded-full bg-violet-600/15 blur-[100px] pointer-events-none" />

      {/* Content card */}
      <div className="relative z-10 w-full max-w-md mx-auto px-6 animate-fade-up">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-3xl bg-gradient-to-br from-blue-500 to-violet-600 mb-6 shadow-2xl shadow-blue-500/30">
            <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.347a1.125 1.125 0 0 1 0 1.972l-11.54 6.347c-.75.412-1.667-.13-1.667-.986V5.653Z" />
            </svg>
          </div>
          <h1 className="text-5xl font-black gradient-text tracking-tighter">NEXUS</h1>
          <p className="text-white/40 text-sm font-medium mt-1 tracking-widest uppercase">Where stories unfold</p>
        </div>

        {/* Glass card */}
        <div className="rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 p-8 shadow-2xl">
          <h2 className="text-2xl font-bold text-white mb-2">Welcome</h2>
          <p className="text-white/50 text-sm mb-8 leading-relaxed">
            Let's personalize your streaming experience. Tell us who you are.
          </p>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">
                Your name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name..."
                className="w-full px-5 py-4 rounded-2xl bg-white/6 backdrop-blur-sm border border-white/10 text-white placeholder-white/30 focus:outline-none focus:border-blue-400/60 focus:bg-white/10 focus:shadow-lg focus:shadow-blue-500/10 transition-all duration-200 text-base font-medium"
                autoFocus
              />
            </div>

            <button
              type="submit"
              disabled={!name.trim()}
              className="w-full py-4 rounded-2xl font-bold text-white bg-gradient-to-r from-blue-500 to-violet-600 hover:from-blue-400 hover:to-violet-500 disabled:opacity-40 disabled:cursor-not-allowed hover:shadow-xl hover:shadow-blue-500/30 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 text-base"
            >
              Continue to NEXUS →
            </button>
          </form>

          <p className="text-center text-white/25 text-xs mt-6">
            By continuing, you agree to our Terms of Service and Privacy Policy.
          </p>
        </div>

        {/* Floating content preview pills */}
        <div className="flex justify-center gap-3 mt-8 flex-wrap">
          {['4K Ultra HD', 'Dolby Atmos', '10,000+ Titles', 'No Ads'].map((tag) => (
            <span
              key={tag}
              className="px-4 py-1.5 rounded-full bg-white/5 border border-white/8 text-white/50 text-xs font-semibold"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
