import { useState, useMemo } from 'react';
import { allSeries, genres, NavigateFn } from '../data';
import { HeroSection, ContentCard, GenreFilter } from '../components';

const SORT_OPTIONS = ['Popular', 'Rating', 'Newest', 'A–Z'];

export default function SeriesPage({ navigate }: { navigate: NavigateFn }) {
  const [activeGenre, setActiveGenre] = useState('All');
  const [sort, setSort] = useState('Popular');

  const heroSeries = allSeries[0]; // Nexus Protocol

  const filtered = useMemo(() => {
    let items = activeGenre === 'All' ? [...allSeries] : allSeries.filter((s) => s.genre.includes(activeGenre));
    if (sort === 'Rating') items.sort((a, b) => b.rating - a.rating);
    else if (sort === 'Newest') items.sort((a, b) => b.year - a.year);
    else if (sort === 'A–Z') items.sort((a, b) => a.title.localeCompare(b.title));
    return items;
  }, [activeGenre, sort]);

  const sections = [
    { title: 'Popular Right Now', items: allSeries.slice(0, 7) },
    { title: 'New Series', items: [...allSeries].sort((a, b) => b.year - a.year).slice(0, 7) },
    { title: 'Top Rated', items: [...allSeries].sort((a, b) => b.rating - a.rating).slice(0, 7) },
    { title: 'Sci-Fi & Fantasy', items: allSeries.filter((s) => s.genre.some((g) => ['Sci-Fi', 'Fantasy'].includes(g))).slice(0, 7) },
    { title: 'Crime & Thriller', items: allSeries.filter((s) => s.genre.some((g) => ['Crime', 'Thriller', 'Spy'].includes(g))).slice(0, 7) },
  ];

  return (
    <div className="min-h-screen pb-28 md:pb-8">
      {/* Hero */}
      <HeroSection item={heroSeries} navigate={navigate} height="medium" />

      {/* Stats bar */}
      <div className="px-6 lg:px-12 mt-8 mb-10">
        <div className="flex flex-wrap gap-3">
          {[
            { label: 'Total Series', value: `${allSeries.length}+` },
            { label: 'New This Month', value: '6' },
            { label: 'Top Rated', value: '9.1/10' },
            { label: 'Seasons Available', value: '60+' },
          ].map((stat) => (
            <div key={stat.label} className="px-5 py-3 rounded-2xl bg-white/5 border border-white/8 flex items-center gap-3">
              <span className="text-white font-black text-xl">{stat.value}</span>
              <span className="text-white/40 text-xs font-semibold">{stat.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Featured sections */}
      <div className="space-y-0">
        {sections.map((sec) =>
          sec.items.length === 0 ? null : (
            <section key={sec.title} className="mb-12">
              <div className="flex items-center justify-between mb-4 px-6 lg:px-12">
                <h2 className="text-lg md:text-xl font-bold text-white">{sec.title}</h2>
                <button className="text-sm text-blue-400 hover:text-blue-300 transition-colors font-medium">
                  View all →
                </button>
              </div>
              <div className="flex gap-4 overflow-x-auto pb-3 px-6 lg:px-12 scrollbar-hide">
                {sec.items.map((item) => (
                  <ContentCard key={item.id} item={item} navigate={navigate} />
                ))}
              </div>
            </section>
          )
        )}
      </div>

      {/* Browse all */}
      <div className="px-6 lg:px-12 mt-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black text-white">All Series</h2>
          <div className="flex gap-1">
            {SORT_OPTIONS.map((opt) => (
              <button
                key={opt}
                onClick={() => setSort(opt)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  sort === opt
                    ? 'bg-blue-500/20 border border-blue-500/40 text-blue-300'
                    : 'bg-white/5 border border-white/8 text-white/50 hover:text-white'
                }`}
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
        <div className="mb-6">
          <GenreFilter genres={genres} active={activeGenre} onChange={setActiveGenre} />
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-4 pb-8">
          {filtered.map((item) => (
            <ContentCard key={item.id} item={item} navigate={navigate} size="sm" />
          ))}
        </div>
      </div>
    </div>
  );
}
