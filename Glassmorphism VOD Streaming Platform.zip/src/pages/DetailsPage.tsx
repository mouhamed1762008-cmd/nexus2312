import { useState } from 'react';
import { ContentItem, NavigateFn, movies, allSeries } from '../data';
import { StarRating, ContentCard } from '../components';

function CastPill({ name }: { name: string }) {
  return (
    <span className="px-3 py-1.5 rounded-full bg-white/6 border border-white/8 text-white/70 text-sm font-medium whitespace-nowrap">
      {name}
    </span>
  );
}

export default function DetailsPage({
  item,
  navigate,
}: {
  item: ContentItem | null;
  navigate: NavigateFn;
}) {
  const [inMyList, setInMyList] = useState(false);
  const [activeSeason, setActiveSeason] = useState(1);

  if (!item) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-white/50">Select a title to view details.</p>
      </div>
    );
  }

  const isSeries = item.type === 'series';
  const similar = isSeries
    ? allSeries.filter((s) => s.id !== item.id && s.genre.some((g) => item.genre.includes(g))).slice(0, 8)
    : movies.filter((m) => m.id !== item.id && m.genre.some((g) => item.genre.includes(g))).slice(0, 8);

  const seasons = isSeries && item.seasons ? Array.from({ length: item.seasons }, (_, i) => i + 1) : [];
  const epCount = isSeries && item.totalEpisodes && item.seasons
    ? Math.round(item.totalEpisodes / item.seasons)
    : 0;
  const episodes = Array.from({ length: epCount || 8 }, (_, i) => ({
    num: i + 1,
    title: `Episode ${i + 1}`,
    duration: item.duration,
    thumb: `https://picsum.photos/seed/${item.id}ep${i}/320/180`,
  }));

  return (
    <div className="min-h-screen pb-28 md:pb-8">
      {/* Backdrop */}
      <div className="relative h-[60vh] min-h-[400px] overflow-hidden">
        <img
          src={item.backdrop}
          alt={item.title}
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-base via-base/80 to-base/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-base via-transparent to-base/20" />

        {/* Back button */}
        <button
          onClick={() => navigate(item.type === 'movie' ? 'movies' : 'series')}
          className="absolute top-20 left-6 lg:left-12 flex items-center gap-2 text-white/70 hover:text-white transition-colors text-sm font-semibold"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
            <path d="m15 18-6-6 6-6" />
          </svg>
          Back
        </button>
      </div>

      {/* Main content — poster + info */}
      <div className="px-6 lg:px-12 -mt-32 relative z-10">
        <div className="flex flex-col md:flex-row gap-8 items-start">
          {/* Poster */}
          <div className="flex-none w-36 md:w-52 rounded-2xl overflow-hidden border border-white/10 shadow-2xl shadow-black/60 self-center md:self-start">
            <img src={item.poster} alt={item.title} className="w-full aspect-[2/3] object-cover" />
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0 pt-0 md:pt-8">
            {/* Genres */}
            <div className="flex flex-wrap gap-2 mb-3">
              {item.genre.map((g) => (
                <span key={g} className="text-xs font-bold px-3 py-1 rounded-full bg-blue-500/15 border border-blue-500/25 text-blue-300">
                  {g}
                </span>
              ))}
            </div>

            {/* Title */}
            <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight mb-3 leading-none">
              {item.title}
            </h1>

            {/* Meta */}
            <div className="flex flex-wrap items-center gap-4 text-sm mb-5">
              <StarRating rating={item.rating} />
              <span className="text-white/60">{item.year}</span>
              <span className="text-white/60">{item.duration}</span>
              {isSeries && item.seasons && (
                <span className="text-white/60">{item.seasons} Season{item.seasons > 1 ? 's' : ''}</span>
              )}
              <span className="text-xs px-2 py-0.5 rounded border border-white/20 text-white/50 font-bold">
                {item.ageRating}
              </span>
            </div>

            {/* Description */}
            <p className="text-white/70 leading-relaxed mb-6 max-w-2xl">{item.description}</p>

            {/* Director & Cast */}
            <div className="space-y-3 mb-7">
              <div>
                <span className="text-white/40 text-xs font-bold uppercase tracking-wider mr-3">Director</span>
                <span className="text-white/80 text-sm font-semibold">{item.director}</span>
              </div>
              <div>
                <span className="text-white/40 text-xs font-bold uppercase tracking-wider mb-2 block">Cast</span>
                <div className="flex flex-wrap gap-2">
                  {item.cast.map((c) => <CastPill key={c} name={c} />)}
                </div>
              </div>
            </div>

            {/* CTA buttons */}
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => navigate('player', item)}
                className="flex items-center gap-2 px-7 py-3.5 rounded-2xl font-bold text-white bg-gradient-to-r from-blue-500 to-violet-600 hover:from-blue-400 hover:to-violet-500 hover:-translate-y-0.5 hover:shadow-lg hover:shadow-blue-500/30 transition-all duration-200"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M5 3l14 9-14 9V3z" /></svg>
                {isSeries ? 'Play S1 E1' : 'Play Now'}
              </button>
              <button
                onClick={() => setInMyList(!inMyList)}
                className={`flex items-center gap-2 px-7 py-3.5 rounded-2xl font-semibold transition-all duration-200 border ${
                  inMyList
                    ? 'bg-blue-500/20 border-blue-500/50 text-blue-300'
                    : 'bg-white/8 border-white/12 text-white hover:bg-white/15'
                }`}
              >
                <svg className="w-4 h-4" fill={inMyList ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
                  <path d="M12 5v14m-7-7h14" />
                </svg>
                {inMyList ? 'In My List' : 'Add to List'}
              </button>
              <button className="flex items-center gap-2 px-5 py-3.5 rounded-2xl font-semibold text-white/70 bg-white/6 border border-white/8 hover:bg-white/12 hover:text-white transition-all duration-200">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
                  <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" /><polyline points="16 6 12 2 8 6" /><line x1="12" y1="2" x2="12" y2="15" />
                </svg>
                Share
              </button>
            </div>
          </div>
        </div>

        {/* Episodes section (series only) */}
        {isSeries && seasons.length > 0 && (
          <div className="mt-14">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-2xl font-black text-white">Episodes</h2>
              <div className="flex gap-2">
                {seasons.map((s) => (
                  <button
                    key={s}
                    onClick={() => setActiveSeason(s)}
                    className={`px-4 py-1.5 rounded-xl text-sm font-bold transition-all ${
                      activeSeason === s
                        ? 'bg-blue-500/20 border border-blue-500/40 text-blue-300'
                        : 'bg-white/5 border border-white/8 text-white/50 hover:text-white'
                    }`}
                  >
                    S{s}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-3">
              {episodes.map((ep) => (
                <button
                  key={ep.num}
                  onClick={() => navigate('player', item)}
                  className="w-full flex items-center gap-4 p-4 rounded-2xl bg-white/4 border border-white/7 hover:bg-white/8 hover:border-white/15 transition-all group text-left"
                >
                  <span className="text-white/30 font-black text-xl w-8 flex-none text-center">
                    {ep.num}
                  </span>
                  <div className="w-28 md:w-36 flex-none rounded-xl overflow-hidden">
                    <img src={ep.thumb} alt="" className="w-full aspect-video object-cover group-hover:scale-105 transition-transform" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-white text-sm mb-0.5">
                      {activeSeason > 1 ? `S${activeSeason} · ` : ''}Ep {ep.num}: {ep.title}
                    </p>
                    <p className="text-white/40 text-xs">{ep.duration}</p>
                  </div>
                  <svg className="w-5 h-5 text-white/30 group-hover:text-blue-400 transition-colors flex-none" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                    <circle cx="12" cy="12" r="10" />
                    <path d="m10 8 6 4-6 4V8z" fill="currentColor" />
                  </svg>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Similar content */}
        {similar.length > 0 && (
          <div className="mt-14">
            <h2 className="text-2xl font-black text-white mb-6">More Like This</h2>
            <div className="flex gap-4 overflow-x-auto pb-3 scrollbar-hide">
              {similar.map((s) => (
                <ContentCard key={s.id} item={s} navigate={navigate} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
