import { NavigateFn, featuredHero, continueWatching, trending, popularMovies, popularSeries, newReleases, recommended } from '../data';
import { HeroSection, ContentRow } from '../components';

export default function HomePage({
  navigate,
  userName,
}: {
  navigate: NavigateFn;
  userName: string;
}) {
  return (
    <div className="min-h-screen pb-24 md:pb-8">
      {/* Hero */}
      <div className="pt-0">
        <HeroSection item={featuredHero} navigate={navigate} height="tall" />
      </div>

      {/* Content rows */}
      <div className="mt-8 space-y-0">
        <ContentRow
          title="Continue Watching"
          items={continueWatching}
          navigate={navigate}
          icon="▶"
        />
        <ContentRow
          title="Trending Now"
          items={trending}
          navigate={navigate}
          icon="🔥"
        />
        <ContentRow
          title="Popular Movies"
          items={popularMovies}
          navigate={navigate}
          icon="🎬"
        />
        <ContentRow
          title="Popular Series"
          items={popularSeries}
          navigate={navigate}
          icon="📺"
        />
        <ContentRow
          title="New Releases"
          items={newReleases}
          navigate={navigate}
          icon="✨"
        />
        <ContentRow
          title={`Recommended for ${userName || 'You'}`}
          items={recommended}
          navigate={navigate}
          icon="⭐"
        />
      </div>
    </div>
  );
}
