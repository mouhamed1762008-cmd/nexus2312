import type { ReactNode } from 'react';
import { ContentItem, NavigateFn, Page } from './data';

// ── Ambient Background ──────────────────────────────────────────────────────

export function AmbientBg() {
  return (
    <>
      <div className="ambient-blob w-[900px] h-[900px] -top-64 -left-64 bg-blue-600/8" />
      <div className="ambient-blob w-[700px] h-[700px] -bottom-48 -right-48 bg-violet-600/10" />
      <div className="ambient-blob w-[500px] h-[500px] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-cyan-600/4" />
    </>
  );
}

// ── Star rating helper ───────────────────────────────────────────────────────

export function StarRating({ rating }: { rating: number }) {
  return (
    <span className="flex items-center gap-1 text-amber-400 font-semibold text-sm">
      <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
      </svg>
      {rating.toFixed(1)}
    </span>
  );
}

// ── Content Card ─────────────────────────────────────────────────────────────

export function ContentCard({
  item,
  navigate,
  size = 'md',
}: {
  item: ContentItem;
  navigate: NavigateFn;
  size?: 'sm' | 'md' | 'lg';
}) {
  const widths = { sm: 'w-32 md:w-36', md: 'w-36 md:w-44', lg: 'w-44 md:w-56' };
  return (
    <div
      className={`group relative ${widths[size]} flex-none cursor-pointer`}
      onClick={() => navigate('details', item)}
    >
      <div className="relative rounded-2xl overflow-hidden bg-white/5 border border-white/8 transition-all duration-300 group-hover:scale-105 group-hover:-translate-y-1 group-hover:border-white/20 group-hover:shadow-xl group-hover:shadow-black/50">
        <img
          src={item.poster}
          alt={item.title}
          className="w-full aspect-[2/3] object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {/* Progress bar for continue watching */}
        {item.progress !== undefined && (
          <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-white/10">
            <div
              className="h-full bg-gradient-to-r from-blue-500 to-violet-500 rounded-full"
              style={{ width: `${item.progress}%` }}
            />
          </div>
        )}
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-3">
          <div className="text-xs text-amber-400 font-semibold mb-1 flex items-center gap-1">
            <svg className="w-3 h-3 fill-current" viewBox="0 0 24 24">
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
            </svg>
            {item.rating}
          </div>
          <h3 className="font-bold text-white text-xs leading-tight mb-2">{item.title}</h3>
          <button
            className="py-1.5 rounded-lg bg-white/20 backdrop-blur-sm text-white text-xs font-semibold hover:bg-blue-500/70 transition-colors"
            onClick={(e) => { e.stopPropagation(); navigate('player', item); }}
          >
            ▶ Play
          </button>
        </div>
        {/* Series badge */}
        {item.type === 'series' && item.seasons && (
          <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-sm text-white text-[10px] font-bold px-2 py-0.5 rounded-full border border-white/10">
            {item.seasons}S
          </div>
        )}
      </div>
      <p className="mt-2 text-xs font-medium text-white/70 truncate px-0.5">{item.title}</p>
    </div>
  );
}

// ── Content Row (horizontal carousel section) ────────────────────────────────

export function ContentRow({
  title,
  items,
  navigate,
  size = 'md',
  icon,
}: {
  title: string;
  items: ContentItem[];
  navigate: NavigateFn;
  size?: 'sm' | 'md' | 'lg';
  icon?: string;
}) {
  return (
    <section className="mb-12">
      <div className="flex items-center justify-between mb-4 px-6 lg:px-12">
        <h2 className="text-lg md:text-xl font-bold text-white flex items-center gap-2">
          {icon && <span>{icon}</span>}
          {title}
        </h2>
        <button className="text-sm text-blue-400 hover:text-blue-300 transition-colors font-medium">
          View all →
        </button>
      </div>
      <div className="flex gap-4 overflow-x-auto pb-3 px-6 lg:px-12 scrollbar-hide">
        {items.map((item) => (
          <ContentCard key={item.id} item={item} navigate={navigate} size={size} />
        ))}
      </div>
    </section>
  );
}

// ── Navbar ───────────────────────────────────────────────────────────────────

const NAV_LINKS: { label: string; page: Page }[] = [
  { label: 'Home', page: 'home' },
  { label: 'Movies', page: 'movies' },
  { label: 'Series', page: 'series' },
  { label: 'Live TV', page: 'live' },
];

export function Navbar({
  currentPage,
  navigate,
  userName,
}: {
  currentPage: Page;
  navigate: NavigateFn;
  userName: string;
}) {
  return (
    <header className="fixed top-0 inset-x-0 z-50 h-16 flex items-center px-6 lg:px-12 bg-black/30 backdrop-blur-2xl border-b border-white/5">
      {/* Logo */}
      <button
        onClick={() => navigate('home')}
        className="font-black text-2xl gradient-text tracking-tight mr-10 flex-shrink-0"
      >
        NEXUS
      </button>

      {/* Desktop nav links */}
      <nav className="hidden md:flex items-center gap-8 flex-1">
        {NAV_LINKS.map(({ label, page }) => (
          <button
            key={page}
            onClick={() => navigate(page)}
            className={`text-sm font-semibold transition-colors ${
              currentPage === page
                ? 'text-white'
                : 'text-white/50 hover:text-white/90'
            } relative pb-0.5`}
          >
            {label}
            {currentPage === page && (
              <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r from-blue-500 to-violet-500 rounded-full" />
            )}
          </button>
        ))}
      </nav>

      {/* Right actions */}
      <div className="flex items-center gap-3 ml-auto">
        {/* Search */}
        <button
          onClick={() => navigate('search')}
          className="w-9 h-9 flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/10 border border-white/8 transition-colors text-white/70 hover:text-white"
          aria-label="Search"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
          </svg>
        </button>

        {/* Notifications */}
        <button className="w-9 h-9 flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/10 border border-white/8 transition-colors text-white/70 hover:text-white relative">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.73 21a2 2 0 0 1-3.46 0" />
          </svg>
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-blue-500" />
        </button>

        {/* Profile */}
        <button
          onClick={() => navigate('profile')}
          className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/8 transition-colors"
        >
          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-500 to-violet-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
            {userName ? userName[0].toUpperCase() : 'U'}
          </div>
          <span className="hidden lg:block text-sm font-medium text-white/80 max-w-24 truncate">
            {userName || 'Profile'}
          </span>
        </button>
      </div>
    </header>
  );
}

// ── Mobile Bottom Nav ─────────────────────────────────────────────────────────

const MOBILE_NAV: { icon: ReactNode; label: string; page: Page }[] = [
  {
    page: 'home',
    label: 'Home',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
        <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" /><polyline points="9 22 9 12 15 12 15 22" />
      </svg>
    ),
  },
  {
    page: 'movies',
    label: 'Movies',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
        <rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18" />
        <line x1="7" y1="2" x2="7" y2="22" /><line x1="17" y1="2" x2="17" y2="22" />
        <line x1="2" y1="12" x2="22" y2="12" /><line x1="2" y1="7" x2="7" y2="7" />
        <line x1="2" y1="17" x2="7" y2="17" /><line x1="17" y1="17" x2="22" y2="17" />
        <line x1="17" y1="7" x2="22" y2="7" />
      </svg>
    ),
  },
  {
    page: 'series',
    label: 'Series',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
        <rect x="2" y="7" width="20" height="15" rx="2" ry="2" />
        <polyline points="17 2 12 7 7 2" />
      </svg>
    ),
  },
  {
    page: 'live',
    label: 'Live',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="10" /><circle cx="12" cy="12" r="3" />
      </svg>
    ),
  },
  {
    page: 'profile',
    label: 'Profile',
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
      </svg>
    ),
  },
];

export function MobileNav({ currentPage, navigate }: { currentPage: Page; navigate: NavigateFn }) {
  return (
    <nav className="md:hidden fixed bottom-0 inset-x-0 z-50 bg-black/60 backdrop-blur-2xl border-t border-white/5 pb-safe">
      <div className="flex items-center justify-around px-2 py-2">
        {MOBILE_NAV.map(({ page, label, icon }) => {
          const active = currentPage === page;
          return (
            <button
              key={page}
              onClick={() => navigate(page)}
              className={`flex flex-col items-center gap-1 py-2 px-3 rounded-xl transition-colors min-w-0 ${
                active ? 'text-blue-400' : 'text-white/40'
              }`}
            >
              {icon}
              <span className="text-[10px] font-semibold truncate">{label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

// ── Hero Section (reusable) ───────────────────────────────────────────────────

export function HeroSection({
  item,
  navigate,
  height = 'tall',
}: {
  item: ContentItem;
  navigate: NavigateFn;
  height?: 'tall' | 'medium';
}) {
  const h = height === 'tall' ? 'h-[75vh] min-h-[550px]' : 'h-[55vh] min-h-[380px]';
  return (
    <section className={`relative ${h} overflow-hidden flex-shrink-0`}>
      <img
        src={item.backdrop}
        alt={item.title}
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-base via-base/70 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-base via-base/20 to-transparent" />

      <div className="relative h-full flex items-end pb-16 px-6 lg:px-12">
        <div className="max-w-xl animate-fade-up">
          {/* Genre badges */}
          <div className="flex flex-wrap gap-2 mb-4">
            {item.genre.map((g) => (
              <span key={g} className="text-xs font-semibold px-3 py-1 rounded-full bg-blue-500/20 border border-blue-500/30 text-blue-300">
                {g}
              </span>
            ))}
          </div>
          {/* Title */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-black text-white leading-none mb-3 tracking-tight">
            {item.title}
          </h1>
          {/* Meta row */}
          <div className="flex flex-wrap items-center gap-4 text-sm font-medium mb-4">
            <StarRating rating={item.rating} />
            <span className="text-white/60">{item.year}</span>
            <span className="text-white/60">{item.duration}</span>
            <span className="text-xs px-2 py-0.5 rounded border border-white/20 text-white/60 font-semibold">
              {item.ageRating}
            </span>
          </div>
          {/* Description */}
          <p className="text-white/70 text-sm md:text-base leading-relaxed mb-8 line-clamp-3 max-w-md">
            {item.description}
          </p>
          {/* CTA buttons */}
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => navigate('player', item)}
              className="flex items-center gap-2 px-7 py-3.5 rounded-2xl font-bold text-white bg-gradient-to-r from-blue-500 to-violet-600 hover:from-blue-400 hover:to-violet-500 hover:-translate-y-0.5 hover:shadow-lg hover:shadow-blue-500/30 transition-all duration-200"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M5 3l14 9-14 9V3z" /></svg>
              Watch Now
            </button>
            <button
              onClick={() => navigate('details', item)}
              className="flex items-center gap-2 px-7 py-3.5 rounded-2xl font-semibold text-white bg-white/10 backdrop-blur-xl border border-white/15 hover:bg-white/20 hover:-translate-y-0.5 transition-all duration-200"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" /><path d="M12 8v4m0 4h.01" /></svg>
              More Info
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

// ── Genre Filter Bar ──────────────────────────────────────────────────────────

export function GenreFilter({
  genres,
  active,
  onChange,
}: {
  genres: string[];
  active: string;
  onChange: (g: string) => void;
}) {
  return (
    <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
      {genres.map((g) => (
        <button
          key={g}
          onClick={() => onChange(g)}
          className={`flex-none px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 ${
            active === g
              ? 'bg-gradient-to-r from-blue-500 to-violet-600 text-white shadow-md shadow-blue-500/25'
              : 'bg-white/6 border border-white/8 text-white/60 hover:bg-white/10 hover:text-white'
          }`}
        >
          {g}
        </button>
      ))}
    </div>
  );
}
