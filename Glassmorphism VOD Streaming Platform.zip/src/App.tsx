import { useState } from 'react';
import { Page, ContentItem } from './data';
import { AmbientBg, Navbar, MobileNav } from './components';
import WelcomePage from './pages/WelcomePage';
import HomePage from './pages/HomePage';
import SearchPage from './pages/SearchPage';
import LivePage from './pages/LivePage';
import MoviesPage from './pages/MoviesPage';
import SeriesPage from './pages/SeriesPage';
import DetailsPage from './pages/DetailsPage';
import PlayerPage from './pages/PlayerPage';
import ProfilePage from './pages/ProfilePage';

export default function App() {
  const [page, setPage] = useState<Page>('welcome');
  const [userName, setUserName] = useState('');
  const [selectedItem, setSelectedItem] = useState<ContentItem | null>(null);

  const navigate = (p: Page, item?: ContentItem) => {
    setPage(p);
    if (item !== undefined) setSelectedItem(item);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const showNav = page !== 'welcome' && page !== 'player';

  return (
    <div className="min-h-screen bg-base text-white overflow-x-hidden font-sans relative">
      {/* Ambient background lighting */}
      <AmbientBg />

      {/* Navigation */}
      {showNav && (
        <Navbar currentPage={page} navigate={navigate} userName={userName} />
      )}

      {/* Pages */}
      <main className={showNav ? 'pt-16' : ''}>
        {page === 'welcome' && (
          <WelcomePage
            onContinue={(name) => {
              setUserName(name);
              navigate('home');
            }}
          />
        )}
        {page === 'home' && <HomePage navigate={navigate} userName={userName} />}
        {page === 'search' && <SearchPage navigate={navigate} />}
        {page === 'live' && <LivePage navigate={navigate} />}
        {page === 'movies' && <MoviesPage navigate={navigate} />}
        {page === 'series' && <SeriesPage navigate={navigate} />}
        {page === 'details' && <DetailsPage item={selectedItem} navigate={navigate} />}
        {page === 'player' && <PlayerPage item={selectedItem} navigate={navigate} />}
        {page === 'profile' && <ProfilePage navigate={navigate} userName={userName} />}
      </main>

      {/* Mobile bottom nav */}
      {showNav && <MobileNav currentPage={page} navigate={navigate} />}
    </div>
  );
}
